from django.urls import path

from . import views

app_name = 'parcelas'

urlpatterns = [
    path('', views.ParcelaListView.as_view(), name='lista'),
    path('nueva/', views.ParcelaCreateView.as_view(), name='crear'),
    path('<int:pk>/editar/', views.ParcelaUpdateView.as_view(), name='editar'),
    path('<int:pk>/eliminar/', views.ParcelaDeleteView.as_view(), name='eliminar'),
    path('<int:pk>/historial/', views.historial, name='historial'),
    path('<int:pk>/historial/<int:hpk>/eliminar/', views.historial_eliminar, name='historial_eliminar'),
    path('<int:pk>/suelo/', views.suelo, name='suelo'),
    path('<int:pk>/suelo/<int:spk>/eliminar/', views.suelo_eliminar, name='suelo_eliminar'),
    path('sincronizar/', views.sincronizar, name='sincronizar'),
]